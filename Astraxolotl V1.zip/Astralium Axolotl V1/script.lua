-- Auto generated script file --
vanilla_model.ALL:setVisible(false)

--hide vanilla armor model
vanilla_model.ARMOR:setVisible(false)
--re-enable the helmet item
vanilla_model.BOOTS:setVisible(true)

--hide vanilla cape model
vanilla_model.CAPE:setVisible(false)

--hide vanilla elytra model
vanilla_model.ELYTRA:setVisible(false)

vanilla_model.HELD_ITEMS:setVisible(true)
vanilla_model.PARROTS:setVisible(true)

local modelcolor = vec(1,0,0) --set colour

--entity init event, used for when the avatar entity is loaded for the first time
function events.entity_init()
  --player functions goes here
end

--tick event, called 20 times per second
function events.tick()
  --code goes here
end

--script.lua

--Remplacez "monModele" par le nom de votre fichier Blockbench (sans .bbmodel)
--Exemple : si votre fichier s'appelle "perso.bbmodel", utilisez models.perso.Head

local head = models.model.Head

--On définit ici le ParentType à "Head" pour que ce ModelPart suive les rotations de la tête vanilla

function events.tick()
    if player:getVehicle() then
        models.model:setPos(0,6.5,0)
      else
        models.model:setPos(0,0,0)
      end
end

--render event, called every time your avatar is rendered
--it have two arguments, "delta" and "context"
--"delta" is the percentage between the last and the next tick (as a decimal value, 0.0 to 1.0)
--"context" is a string that tells from where this render event was called (the paperdoll, gui, player render, first person)
function events.render(delta, context)
  --code goes here
  if player:isCrouching() then
  models:setPos(0, -4.75, 0)
  else
models:setPos(0, -6.75, 0)
end
end
